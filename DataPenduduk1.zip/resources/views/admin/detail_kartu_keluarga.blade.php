@extends('template.layout')

@section('title'. 'Data Penduduk')

@section('content')
    <div class="section-header">
        <h1>Data Kartu Keluarga Penduduk</h1>
    </div>

    <div class="section-body">
        <h2 class="section-title">Data Kartu Keluarga Penduduk</h2>
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Input Data Kartu Keluarga Penduduk</h4>
                    </div>
                    <div class="card-body">
                        
                    </div>
                </div>
                
            </div>
        </div>
    </div>

@endsection

@push('scripts')
<script>
</script>
    
@endpush